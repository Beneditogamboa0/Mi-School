<?php
function setUserInfo($id, $type, $name)
{
    session_start();
    $_SESSION["id"] = $id;
    $_SESSION["name"]=$name;
    $_SESSION["type"] = $type;
}