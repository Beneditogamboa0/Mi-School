<?php
require_once "../controller/admin-controller.php";
$option = $_GET["s"];
switch ($option) {
    case "students":
        listStudents();
        break;
    case "studentInfo":
        listStudentInfo();
        break;
    case "studentMarks":
        listStudentMarks();
        break;
    case "studentPresences":
        listStudentPresences();
        break;
    case "registerStudent":
        registerStudent();
        break;
    case "updateStudent":
        updateStudent();
        break;
    case "registerTeacher":
        registerTeacher();
        break;
    case "teacherInfo":
        listTeacherInfo();
        break;
    case "teachers":
        listTeachers();
        break;
    case "courses":
        listCourses();
        break;
    case "grades":
        listGrades();
        break;
    case "registerOptions":
        getRegisterOptions();
        break;
    case "stats":
        generalStats();
        break;
}