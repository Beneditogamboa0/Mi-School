<?php
include_once __DIR__ . ("/../model/user-model.php");
include_once __DIR__ . ("/../validations/checkCredentials.php");
include_once __DIR__ . ("/../sessions/startSession.php");
$user = json_decode(file_get_contents("php://input"), true);
function signUp()
{
    global $user;
    $userObj = new User($user["bi"], $user["password"], $user["userType"]);
    $check=checkCredentials($user["bi"],$user["password"]);
    if(!$check["status"]){
        echo json_encode($check);
        die();
    }
    echo json_encode($userObj->signUp());
}
function login(){
    global $user;
    $check=checkCredentials($user["bi"],$user["password"]);
    if(!$check["status"]){
        echo json_encode($check);
        die();
    }
    $login=User::login($user["bi"],$user["password"]);
    if(!$login["status"]){
        echo json_encode($login);
        die();
    }
    setUserInfo($login["user"]["id"],$login["user"]["tipo_usuario"],$login["user"]["nome"]);
    echo json_encode($login);
    die();
}