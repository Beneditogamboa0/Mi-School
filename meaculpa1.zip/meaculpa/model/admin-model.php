<?php
require_once __DIR__ . "/../config/config.php";
header("content-type: application/json");

class Admin
{
    public function listAllStudents()
    {   
        global $con;
        $query = $con->prepare("SELECT alunos.id,alunos.nome,
            classes.numero as classe,cursos.nome as curso,turmas.nome as turma from alunos
            join classes on classes.id=alunos.id_classe
            join cursos on cursos.id=alunos.id_curso
            join turmas on turmas.id=alunos.id_turma order by alunos.nome asc");
        $query->execute();
        $students = $query->fetchAll(PDO::FETCH_ASSOC);
        return $students;
    }

    public static function listStudentInformation($id)
    {
        global $con;
        $query = $con->prepare("SELECT alunos.nome,alunos.data_nascimento,alunos.bi,
            classes.numero as classe,cursos.nome as curso,encarregados.nome as encarregado, encarregados.bi as bi_encarregado,
            contacto_encarregado.telefone as telefone_encarregado, contacto_encarregado.telefone_secundario,
            contacto_encarregado.email as email_encarregado,turmas.nome as turma from alunos
            join encarregados on alunos.id_encarregado=encarregados.id
            join contacto_encarregado on encarregados.id=contacto_encarregado.id_encarregado
            join classes on classes.id=alunos.id_classe
            join cursos on cursos.id=alunos.id_curso
            join turmas on turmas.id=alunos.id_turma where alunos.id=?");
        $query->execute([$id]);
        $student = $query->fetch(PDO::FETCH_ASSOC);
        return $student;
    }

    public function listAllTeachers()
    {
        global $con;
        $query = $con->prepare("SELECT id, nome from professores");
        $query->execute();
        $teachers = $query->fetchAll(PDO::FETCH_ASSOC);
        foreach ($teachers as $t_index => $teacher) {
            $classes = $con->prepare("SELECT classes.numero as classe from professor_classe
                join professores on professores.id=professor_classe.id_professor
                join classes on classes.id=professor_classe.id_classe
                where professores.id=?");
            $classes->execute([$teachers[$t_index]["id"]]);
            $teachers[$t_index]["classes"] = $classes->fetchAll(PDO::FETCH_ASSOC);

            $cursos = $con->prepare("SELECT cursos.nome as curso from professor_curso
                join professores on professores.id=professor_curso.id_professor
                join cursos on cursos.id=professor_curso.id_curso
                where professores.id=?");
            $cursos->execute([$teachers[$t_index]["id"]]);
            $teachers[$t_index]["cursos"] = $cursos->fetchAll(PDO::FETCH_ASSOC);

            $turmas = $con->prepare("SELECT turmas.nome as turma from professor_turma
                join professores on professores.id=professor_turma.id_professor
                join turmas on turmas.id=professor_turma.id_turma
                where professores.id=?");
            $turmas->execute([$teachers[$t_index]["id"]]);
            $teachers[$t_index]["turmas"] = $turmas->fetchAll(PDO::FETCH_ASSOC);
        }
        return $teachers;
    }

    public static function listTeacherInformation($id)
    {
        global $con;
        $query = $con->prepare("SELECT * from professores where id=?");
        $query->execute([$id]);
        $teacher = $query->fetch(PDO::FETCH_ASSOC);
        //classes
        $classes = $con->prepare("SELECT classes.numero as classe from professor_classe
                join professores on professores.id=professor_classe.id_professor
                join classes on classes.id=professor_classe.id_classe
                where professores.id=?");
        $classes->execute([$id]);
        $teacher["classes"] = $classes->fetchAll(PDO::FETCH_ASSOC);

        //cursos
        $cursos = $con->prepare("SELECT cursos.nome as curso from professor_curso
                join professores on professores.id=professor_curso.id_professor
                join cursos on cursos.id=professor_curso.id_curso
                where professores.id=?");
        $cursos->execute([$id]);
        $teacher["cursos"] = $cursos->fetchAll(PDO::FETCH_ASSOC);
        //turmas
        $turmas = $con->prepare("SELECT turmas.nome as turma from professor_turma
                join professores on professores.id=professor_turma.id_professor
                join turmas on turmas.id=professor_turma.id_turma
                where professores.id=?");
        $turmas->execute([$id]);
        $teacher["turmas"] = $turmas->fetchAll(PDO::FETCH_ASSOC);
        //disciplinas
        $disciplinas = $con->prepare("SELECT disciplinas.nome as disciplina from professor_disciplina
        join professores on professores.id=professor_disciplina.id_professor
        join disciplinas on disciplinas.id=professor_disciplina.id_disciplina
        where professores.id=?");
        $disciplinas->execute([$id]);
        $teacher["disciplinas"] = $disciplinas->fetchAll(PDO::FETCH_ASSOC);

        return $teacher;
    }

    public function listCourses()
    {
        global $con;
        $query = $con->prepare("SELECT * from cursos");
        $query->execute();
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function listGrades()
    {
        global $con;
        $query = $con->prepare("SELECT id,numero as classe from classes");
        $query->execute();
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    public static function listStudentMarks($id)
    {
        global $con;
        $query = $con->prepare("SELECT notas.nota as nota,disciplinas.nome as disciplina,
        tipo_teste.nome as teste from aluno_avaliacao
        join alunos on alunos.id=aluno_avaliacao.id_aluno
        join avaliacao on avaliacao.id=aluno_avaliacao.id_avaliacao
        join notas on notas.id=avaliacao.id_nota
        join disciplinas on disciplinas.id=avaliacao.id_disciplina
        join tipo_teste on tipo_teste.id=avaliacao.id_tipo_teste 
        where alunos.id=?");
        $query->execute([$id]);
        $marks = $query->fetchAll(PDO::FETCH_ASSOC);
        return $marks;
    }

    public static function listStudentPresences($id)
    {
        global $con;
        $query = $con->prepare("SELECT presencas.estado,disciplinas.nome,presencas.data from presenca_aluno
        join alunos on alunos.id=presenca_aluno.id_aluno
        join presencas on presencas.id=presenca_aluno.id_presenca
        join disciplinas on disciplinas.id=presencas.id_disciplina
        where alunos.id=?");
        $query->execute([$id]);
        $presences = $query->fetchAll(PDO::FETCH_ASSOC);
        return $presences;
    }

    public static function registerStudent($name, $birthdate, $bi, $parent, $parentBi, $phone, $email, $grade, $course, $class, $secondPhone = null)
    {
        global $con;
        //validações
        $mail = $con->prepare("SELECT id from alunos where bi=?");
        $mail->execute([$bi]);
        if ($mail->fetchColumn())
            return ["status" => false, "msg" => "Já existe um aluno com esse BI"];
        $parentInfo = $con->prepare("SELECT encarregados.bi,contacto_encarregado.telefone,contacto_encarregado.telefone_secundario from encarregados
        join contacto_encarregado on contacto_encarregado.id_encarregado=encarregados.id
        where encarregados.bi=?");
        $parentInfo->execute([$parentBi]);
        $parentInfo = $parentInfo->fetch(PDO::FETCH_ASSOC);
        if ($parentInfo) {
            foreach ($parentInfo as $contact) {
                if ($contact == $parentBi)
                    return ["status" => false, "msg" => "BI de encarregado já cadastrado"];
                else if ($contact == $phone)
                    return ["status" => false, "msg" => "Número de telefone já cadastrado"];
                else if ($contact == $secondPhone)
                    return ["status" => false, "msg" => "Número secundário já cadastrado"];
            }
        }

        $query = $con->prepare("INSERT into alunos (nome,data_nascimento,bi,id_classe,id_curso,id_turma) 
        values (?,?,?,?,?,?)");
        $query->execute([$name, $birthdate, $bi, $grade, $course, $class]);

        $query = $con->prepare("INSERT into encarregados (nome,bi) values (?,?)");
        $query->execute([$parent, $parentBi]);

        $query = $con->prepare("SELECT id from encarregados where bi=?");
        $query->execute([$parentBi]);
        $parentId = $query->fetchColumn();

        $query = $con->prepare("INSERT into contacto_encarregado (id_encarregado,email,telefone,telefone_secundario) values (?,?,?,?)");

        $query->execute([$parentId, $email, $phone, $secondPhone]);

        $query = $con->prepare("UPDATE alunos set id_encarregado=? where bi=?");
        $query->execute([$parentId, $bi]);

        return ["status" => true, "msg" => "Aluno cadastrado com sucesso"];
    }
    public static function registerTeacher($name, $birthdate, $bi, $grades, $courses, $subjects, $classes)
    {
        global $con;

        //validações
        $biCheck = $con->prepare("SELECT id from professores where bi=?");
        $biCheck->execute([$bi]);
        if ($biCheck->fetchColumn())
            return ["status" => false, "msg" => "BI já cadastrado"];

        $query = $con->prepare("INSERT into professores (nome,data_nascimento,bi) values (?,?,?)");
        $query->execute([$name, $birthdate, $bi]);

        $query = $con->prepare("SELECT id from professores where bi=?");
        $query->execute([$bi]);
        $teacherId = $query->fetchColumn();

        foreach ($grades as $grade) {
            $query = $con->prepare("INSERT into professor_classe (id_classe,id_professor) values (?,?)");
            $query->execute([$grade, $teacherId]);
            if (!$query)
                return ["status" => false, "msg" => "Ocorreu um erro"];
        }
        foreach ($courses as $course) {
            $query = $con->prepare("INSERT into professor_curso (id_curso,id_professor) values (?,?)");
            $query->execute([$course, $teacherId]);
            if (!$query)
                return ["status" => false, "msg" => "Ocorreu um erro"];
        }
        foreach ($subjects as $subject) {
            $query = $con->prepare("INSERT into professor_disciplina (id_disciplina,id_professor) values (?,?)");
            $query->execute([$subject, $teacherId]);
            if (!$query)
                return ["status" => false, "msg" => "Ocorreu um erro"];
        }
        foreach ($classes as $class) {
            $query = $con->prepare("INSERT into professor_turma (id_turma,id_professor) values (?,?)");
            $query->execute([$class, $teacherId]);
            if (!$query)
                return ["status" => false, "msg" => "Ocorreu um erro"];
        }
        return ["status" => true, "msg" => "Professor cadastrado com sucesso"];
    }
    /*
    public static function updateStudentInfo($id, $name, $birthdate, $bi, $parent, $parentBi, $phone, $email, $grade, $course, $class, $secondPhone = null)
    {
        global $con;
        $query = $con->prepare("UPDATE alunos set nome=?,data_nascimento=?,bi=?,id_classe=?,id_curso=?,id_turma=? 
        where id=?");
        $query->execute([$name, $birthdate, $bi, $grade, $course, $class, $id]);
        $studentId = $con->prepare("SELECT id from students where bi=?");
        $studentId->execute([$bi]);
        if (!$studentId)
            return ["status" => false, "msg" => "Erro, tente novamente"];
        $studentId = $studentId->fetchColumn();

        $query = $con->prepare("UPDATE encarregados set nome=?,bi=? 
        join alunos on alunos.id_encarregado=encarregados.id where alunos.id=?");
        $query->execute([$parent, $parentBi, $studentId]);
        if (!$query)
            return ["status" => false, "msg" => "Erro, tente novamente"];

        $query = $con->prepare("SELECT id from encarregados where bi=?");
        $query->execute([$parentBi]);
        if ($query)
            return ["status" => false, "msg" => "Erro, tente novamente"];
        $parentId = $query->fetchColumn();

        $query = $con->prepare("UPDATE contacto_encarregado set email=?,telefone=?,telefone_secundario=? where id_encarregado=?");

        $query->execute([$email, $phone, $secondPhone, $parentId]);
        if ($query)
            return ["status" => false, "msg" => "Erro, tente novamente"];
        return ["status" => true, "msg" => "Atualizado com sucesso"];
    }
        */
    public function getCourses()
    {
        global $con;
        $query = $con->prepare("SELECT * from cursos");
        $query->execute();
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    public function getGrades()
    {
        global $con;
        $query = $con->prepare("SELECT * from classes");
        $query->execute();
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    public function getClasses()
    {
        global $con;
        $query = $con->prepare("SELECT id,nome from turmas");
        $query->execute();
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    public function getSubjects()
    {
        global $con;
        $query = $con->prepare("SELECT id,nome from disciplinas");
        $query->execute();
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    public function getGeneralStats()
    {
        global $con;
        $query = $con->prepare("SELECT count(*) from alunos");
        $query->execute();
        $students = $query->fetchColumn();

        $query = $con->prepare("SELECT count(*) from professores");
        $query->execute();
        $teachers = $query->fetchColumn();

        $query = $con->prepare("SELECT count(*) from cursos");
        $query->execute();
        $courses = $query->fetchColumn();

        return [
            "alunos" => $students,
            "professores" => $teachers,
            "cursos" => $courses,
            "melhorClasse" => (new Admin)->getBestGrade(),
            "melhorCurso" => (new Admin)->getBestCourse()
        ];
    }
    public function getBestGrade()
    {
        global $con;
        $query = $con->prepare("SELECT 
    c.numero AS classe,
    AVG(n.nota) AS media_classe
FROM classes c
JOIN alunos a ON a.id_classe = c.id
JOIN aluno_avaliacao aa ON aa.id_aluno = a.id
JOIN avaliacao av ON av.id = aa.id_avaliacao
JOIN notas n ON n.id = av.id_nota
GROUP BY c.id, c.numero
ORDER BY media_classe DESC
LIMIT 1;");
        $query->execute();
        return $highest = $query->fetch(PDO::FETCH_ASSOC);
    }
    public function getBestCourse()
    {
        global $con;
        $query = $con->prepare("SELECT cu.nome AS curso,AVG(n.nota) AS media_curso FROM cursos cu
            JOIN alunos a ON a.id_curso = cu.id
            JOIN aluno_avaliacao aa ON aa.id_aluno = a.id
            JOIN avaliacao av ON av.id = aa.id_avaliacao
            JOIN notas n ON n.id = av.id_nota
            GROUP BY cu.id, cu.nome
            ORDER BY media_curso DESC
            LIMIT 1");
        $query->execute();
        return $best = $query->fetch(PDO::FETCH_ASSOC);
    }

    public function list()
    {
        global $con;
        $query = $con->prepare("SELECT nome from cursos");
        $query->execute();
        $courses = $query->fetchAll(PDO::FETCH_ASSOC);
        foreach ($courses as $c_index => $course) {
            $query = $con->prepare("SELECT count(*) from turmas 
            join cursos on cursos.id=turmas.id_curso
            where cursos.nome=?");
            $query->execute([$course["nome"]]);
            $courses[$c_index]["qtd_turmas"] = $query->fetchColumn();
        }
        return $courses;
    }
}