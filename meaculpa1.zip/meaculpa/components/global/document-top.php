<?php
    require_once "../../../sessions/sessionControl.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php require "../../../../meaculpa/components/global/links.php" ?>
    <title>Schola Mea</title>
</head>

<body>
    <?php require "../../../components/modal/modal.php" ?>
    <?php require "../../../components/message-box/message-box.php" ?>
    <?php require "../../../components/sidebar/sidebar.php" ?>