<script src="/meaculpa/public/js/libraries/chart.js/package/dist/chart.umd.js"></script>
<script src="/meaculpa/public/js/global/site.js"></script>
<script src="/meaculpa/public/js/global/header.js"></script>
<script src="/meaculpa/public/js/global/sidebar.js"></script>