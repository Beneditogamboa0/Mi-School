<div class="addButton">
    <button><i class="fa fa-plus"></i> Adicionar Novo</button>
</div>