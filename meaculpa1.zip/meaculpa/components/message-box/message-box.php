<div class="message-box">
    <div>
        <i class="fa fa-warning"></i>
    </div>
    <span>Mensagem qualquer</span>
</div>