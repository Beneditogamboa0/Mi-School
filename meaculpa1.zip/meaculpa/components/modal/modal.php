<div class="modal">
    <button class="btnCloseModal"><i class="fa fa-plus"></i></button>
    <div class="modal-area">
        <div class="selects">
            <span>Migos</span>
            <form>
                <div>

                    <div>
                        <label for="">Disciplina</label>
                        <select id="disciplina"></select>
                    </div>
                    <div>
                        <label for="">Prova</label>
                        <select id="prova"></select>
                    </div>
                    <div>
                        <label for="">Nota</label>
                        <select id="nota"></select>
                    </div>
                </div>
                <div class="buttons selectBtns">
                    <button type="submit">Publicar Nota</button>
                </div>
            </form>
        </div>
    </div>
</div>