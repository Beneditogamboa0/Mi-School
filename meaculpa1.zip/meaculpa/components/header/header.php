<header>
    <span class="logo">Schola Mea <i class="fa fa-feather"></i></span>
    <div>
        <span class="username"><?=$_SESSION["name"]?></span>
        <img src="/meaculpa/public/images/default-pfp.jpg" alt="" class="pfp">
        <div class="options">
            <span class="logout"><i class="fa fa-power-off"></i> Fazer logout</span>
        </div>
    </div>
</header>