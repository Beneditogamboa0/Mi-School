<!--Topo do documento: Importar sempre-->
<?php require "../../../components/global/document-top.php" ?>

<!--Pôr sempre a main nas páginas-->
<!--
Estilos que dependem da página são referenciados acima da main
    e antes da importação
-->
<link rel="stylesheet" href="/meaculpa/public/css/pages/student/info.css">
<main>
    <?php require "../../../components/header/header.php" ?>
    <div class="my-info">
        <div class="info">
            <div>
                <span>B</span>
                <span>Benedito</span>
            </div>
            <div>
                <span><strong>Número do BI: </strong></span>
                <span><strong>Data de nascimento: </strong></span>
                <span><strong>Classe: </strong></span>
                <span><strong>Curso: </strong></span>
                <span><strong>Turma: </strong></span>
                <span><strong>Meu encarregado: </strong></span>
                <span><strong>Seu BI: </strong></span>
                <span><strong>Seus Contactos: </strong></span>
            </div>
        </div>
        <div class="dashboard">
            <div>
                <span>Estatística geral</span>
                <canvas id="pizza"></canvas>
            </div>
        </div>
    </div>
    <div class="subjects">
        <span>Minhas Disciplinas</span>
        <div class="s_list">
        </div>
    </div>
</main>

<?php require "../../../components/global/document-bottom.php" ?>
<script src="/meaculpa/public/js/pages/student/info.js"></script>
<!--Base do documento: Importar sempre-->