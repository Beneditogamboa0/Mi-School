<?php
    require_once __DIR__."/../../sessions/sessionControl.php";
    $type=$_SESSION["type"];
    switch($type){
        case "Aluno":
            header("Location: /meaculpa/pages/student/info/");
            break;
        case "Professor":
            header("Location: /meaculpa/pages/teacher/students/");
            break;
        case "Admin":
            header("Location: /meaculpa/pages/admin/dashboard/");
            break;
    }