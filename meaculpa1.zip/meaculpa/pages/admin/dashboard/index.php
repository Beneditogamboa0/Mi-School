<!--Topo do documento: Importar sempre-->
<?php require "../../../components/global/document-top.php" ?>

<!--Pôr sempre a main nas páginas-->
<!--
Estilos que dependem da página são referenciados acima da main
    e antes da importação
-->
<link rel="stylesheet" href="/meaculpa/public/css/pages/admin/dashboard.css">
<main>
    <?php require "../../../components/header/header.php" ?>
    <div class="carousel">
        <span>Lista de cursos</span>
        <div class="c_list">
        </div>
    </div>
    <div class="dashboard">
        <div>
            <span>Contagem geral</span>
            <canvas id="teacher-student-course"></canvas>
        </div>
        <div>
            <span>Melhor Aproveitamento (em %)</span>
            <canvas id="grade-course"></canvas>
        </div>
    </div>
</main>

<?php require "../../../components/global/document-bottom.php" ?>
<script src="/meaculpa/public/js/pages/admin/dashboard.js"></script>
<!--Base do documento: Importar sempre-->