<?php
    require_once __DIR__."/../../sessions/sessionControl.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/meaculpa/public/css/pages/loginAndSignup/loginAndSignup.css">
    <link rel="stylesheet" href="/meaculpa/public/fonts/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="/meaculpa/public/css/global/vars.css">
    <link rel="stylesheet" href="/meaculpa/public/css/global/animations.css">
    <link rel="stylesheet" href="/meaculpa/components/message-box/message-box.css">
    <link rel="shortcut icon" href="/meaculpa/public/images/logo.png" type="image/x-icon">
    <title>Schola Mea</title>
</head>

<body>
    <?php require "../../components/message-box/message-box.php" ?>
</body>
<main>
    <div>
        <span class="logo">Schola Mea</span>
        Notas, presenças, informações gerais... Tudo num só lugar! Acesse o nosso aplicativo e desfrute de tudo que ele tem a oferecer.
    </div>
    <div>
        <span>Criar Conta</span>
        <form onsubmit="return signUp()">
            <label for="ibi">Número do BI<em style="color:red;">*</em></label>
            <input id="ibi" type="text" placeholder="Ex.: 123456789LA000" minlength="14" maxlength="14">
            <label for="ipassword">Senha<em style="color:red;">*</em></label>
            <input id="ipassword" type="password" placeholder="Ex.: usuario12345">
            <label for="ipasswordcheck">Confirme a senha<em style="color:red;">*</em></label>
            <input id="ipasswordcheck" type="password" placeholder="Ex.: usuario12345">
            <label for="iuserType">Selecione o tipo de usuário</label>
            <select id="iuserType">
                <option value="2">Aluno</option>
                <option value="1">Professor</option>
            </select>
            <button type="submit">Criar Conta</button>
        </form>
        <span>Um dos nossos?<a href="/meaculpa/pages/login/index.php"> Pode entrar!</a></span>
    </div>
</main>

</html>
<?php require "../../../meaculpa/components/global/scripts.php" ?>
<script src="/meaculpa/public/js/pages/signup.js"></script>