<?php
    function checkBI($bi)
{
  $bi_length = strlen($bi);
  $max_length = 14;

  if ($bi_length > $max_length || $bi_length<10)
    return false;

  return true;
}

function checkPassword($password)
{
  $password = trim($password);
  $password = filter_var($password, FILTER_SANITIZE_EMAIL);
  $min_length = 8;
  $max_length = 30;
  $pass_length = strlen($password);

  if ($pass_length < $min_length || $pass_length > $max_length)
    return false;

  if (str_contains($password, " "))
    return false;

  return true;
}

//função de verificação principal para login:
function checkCredentials($bi, $password)
{
  return checkPassword($password) && checkBI($bi) ?
    ["status" => true, "msg" => "Credenciais verificadas com sucesso"] :
    ["status" => false, "msg" => "Verifique as suas credenciais"];
}