<?php
    $con=null;
    try{
        $con=new PDO("mysql:host=localhost;dbname=scholamea","root");
    }
    catch(PDOException $e){
        echo $e->getMessage();
    }
