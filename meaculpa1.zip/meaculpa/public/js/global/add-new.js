const btnAdd = document.querySelector("div.addButton button")
var stepsLength = 0
var index = 0

btnAdd.addEventListener("click", () => {
    registerForm()
    setTimeout(() => registerPerStep(0), 60)
})
btnAdd.addEventListener("click", toggleModal)

function registerPerStep(i) {
    const zones = document.querySelectorAll(".zone")
    stepsLength = zones.length
    zones.forEach((z) => {
        z.classList.remove("on")
    })
    if (i == 0)
        zones[0].classList.add("on")
    zones[i].classList.add("on")
}
function next() {
    if (index < stepsLength - 1)
        index++
    registerPerStep(index)
}
function previous() {
    if (index > 0)
        index--
    registerPerStep(index)
}