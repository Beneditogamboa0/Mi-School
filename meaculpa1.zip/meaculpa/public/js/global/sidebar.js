document.addEventListener("DOMContentLoaded", () => {
    var pages = document.querySelectorAll("nav a")
    const currentPage = window.location.href.slice(0, window.location.href.lastIndexOf("/"))
    pages.forEach((p) => {
        var page = p.href.slice(0, p.href.lastIndexOf("/"))
        if (currentPage === page) {
            p.childNodes[1].style.backgroundColor = "white"
            p.childNodes[1].style.color = "purple"
        }
    })
})
document.addEventListener("DOMContentLoaded", () => {
    var sidebar = document.querySelector("nav")
    var links = [...sidebar.childNodes[1].childNodes]
    if (sidebar.clientWidth == "50") {
        links.forEach((l) => {
            if (l.className == "link") {
                var icon = l.childNodes[1].innerHTML
                icon=icon.slice(0,icon.lastIndexOf(">")+1)
                l.childNodes[1].innerHTML=icon
            }
        })
    }
})

