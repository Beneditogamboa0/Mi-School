function writePresences(arr) {
    presenceContainer = document.querySelector(".presences")
    presenceContainer.innerText = ""
    if(arr.length==0)
        presenceContainer.innerHTML="<span>Nenhuma presença atribuída</span>"

    arr.forEach((p) => {

        if(presenceContainer.innerText.includes(p.disciplina))
            return

        presenceContainer.innerHTML+=`
            <div class="subject">
            <span>${p.disciplina}</span>
            <div class="s_presences">
                <div>
                    <span>Faltas</span>
                    <span style=background-color:red>${p.faltas}</span>
                </div>
                <div>
                    <span>Presenças</span>
                    <span style=background-color:green>${p.presencas}</span>
                </div>
                <div>
                    <span>Total</span>
                    <span style=background-color:var(--cor1)>${p.total_presencas}</span>
                </div>
            </div>
        </div>
        `
    })
}
async function getPresences() {
    ans = await fetch("/meaculpa/routes/studentRoutes.php?s=presences")
    ans = await ans.json()
    console.log(ans)
    writePresences(ans)
}
getPresences()