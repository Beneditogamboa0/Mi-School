function writeSubjects(arr) {
    subjectContainer = document.querySelector(".subjects")
    subjectContainer.innerText = ""
    arr.forEach((s, i) => {
        div = document.createElement("div")
        div.innerHTML = `
            <span>${s.nome}</span>
        `
        days = document.createElement("span")
        days.classList.add("days")
        s.dias.forEach((d) => {
            days.innerText += `${d.dia_aula}, `
        })
        days.innerText = days.innerText.slice(0, days.innerText.lastIndexOf(","))
        if(s.dias.length==0)
            days.innerText="Nenhum dia atribuído"
        div.appendChild(days)
        subjectContainer.appendChild(div)
    })
}
async function getSubjects() {
    ans = await fetch("../../routes/studentRoutes.php?s=subjects")
    ans = await ans.json()
    writeSubjects(ans)
    console.log(ans)
}
getSubjects()