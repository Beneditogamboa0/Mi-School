async function login() {
    event.preventDefault()
    try {
        const user = {
            bi: ibi.value,
            password: ipassword.value
        }
        for (var atr in user) {
            if (user[atr] == "" || user[atr] == null) {
                showMessage("Preencha todos os campos", "orange", "warning")
                return
            }
        }
        ans = await fetch("/meaculpa/routes/userLogin.php", {
            method: "post",
            body: JSON.stringify(user),
            header: { "content-type": "application/json" }
        })
        ans = await ans.json()
        console.log(ans)
        if (!ans.status) {
            showMessage(ans.msg, "red", "warning")
            return
        }

        showMessage(ans.msg, "green", "check")
        setTimeout(() => window.location.href = "/meaculpa/pages/main/index.php", waitTime)
    } catch (ex) {
        showMessage("Ocorreu algum erro","red","warning")
    }
}