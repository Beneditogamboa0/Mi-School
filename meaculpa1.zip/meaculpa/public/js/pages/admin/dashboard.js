var statsCount = document.getElementById("teacher-student-course")
var gradeCourse = document.getElementById("grade-course")


function writeDashboard(obj) {

    var total = [obj.professores, obj.alunos, obj.cursos]

    new Chart(statsCount, {
        type: "bar",
        data: {
            labels: ["Professores", "Alunos", "Cursos"],
            datasets: [{
                label: "Total",
                data: total,
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    })

    new Chart(gradeCourse, {
        type: "doughnut",
        data: {
            labels: [`Curso: ${obj.melhorCurso.curso}`, `Classe: ${obj.melhorClasse.classe}ª`],
            datasets: [{
                label: "Média geral",
                data: [((obj.melhorCurso.media_curso / 20) * 100), (obj.melhorClasse.media_classe / 20) * 100],
                backgroundColor: ["rgb(144, 0, 144)", "blue"],
                borderWidth: 1
            }]
        }
    })
}
async function getGeneralStats() {
    ans = await fetch("/meaculpa/routes/adminRoutes.php?s=stats")
    ans = await ans.json()
    writeDashboard(ans)
}

function writeCourses(arr) {
    coursesList = document.querySelector(".c_list")
    coursesList.innerHTML=""
    arr.forEach((g) => {
        coursesList.innerHTML+=`
            <div>
                <span>${g.nome}</span>
            </div>
        `
    })
}
async function getCourses() {
    ans = await fetch("/meaculpa/routes/adminRoutes.php?s=courses")
    ans = await ans.json()
    console.log(ans)
    writeCourses(ans)
}
document.addEventListener("DOMContentLoaded", () => {
    getCourses()
    getGeneralStats()
})


//pegar notas dos cursos
//select notas.nota from aluno_avaliacao
// join alunos on alunos.id=aluno_avaliacao.id_aluno
// join avaliacao on avaliacao.id=aluno_avaliacao.id_avaliacao
// join notas on notas.id=avaliacao.id_nota
// join cursos on alunos.id_curso=cursos.id where cursos.id=1;