var s = 0
const date = new Date()
function writeTeachers(arr) {
    teachersContainer = document.querySelector(".user-container")
    teachersContainer.innerText = ""
    if (arr.length == 0){
        teachersContainer.style.display="flex"
        teachersContainer.style.alignItems="center"
        teachersContainer.style.justifyContent="center"
        teachersContainer.innerHTML = "<span style=font-size:var(--fonte-xl)>Nenhum professor registado</span>"
    }
    arr.forEach((t) => {
        div = document.createElement("div")
        div.classList.add("user")
        grades = document.createElement("span")
        courses = document.createElement("span")
        turmas = document.createElement("span")

        grades.innerText = "Classe(s): "
        courses.innerText = "Curso(s): "
        turmas.innerText = "Turma(s): "

        div.innerHTML = `<span>Nome: ${t.nome}</span>`
        t.classes.forEach((g) => {
            grades.innerText += `${g.classe}ª, `
        })
        t.cursos.forEach((c) => {
            courses.innerText += `${c.curso}, `
        })
        t.turmas.forEach((tt) => {
            turmas.innerText += `${tt.turma}, `
        })
        grades.innerText = grades.innerText.slice(0, grades.innerText.lastIndexOf(","))
        courses.innerText = courses.innerText.slice(0, courses.innerText.lastIndexOf(","))
        turmas.innerText = turmas.innerText.slice(0, turmas.innerText.lastIndexOf(","))
        div.appendChild(grades)
        div.appendChild(courses)
        div.appendChild(turmas)
        div.innerHTML += `
            <div class="buttons">
                <button onclick="getTeacherInfo(event);toggleModal()" value=${t.id}>Informações</button>
            </div>
        `
        teachersContainer.appendChild(div)
    })
}
async function getTeachers() {
    ans = await fetch("/meaculpa/routes/adminRoutes.php?s=teachers")
    ans = await ans.json()
    console.log(ans)
    writeTeachers(ans)
}
document.addEventListener("DOMContentLoaded", getTeachers)

function writeTeacherInfo(obj) {
    modalArea = document.querySelector(".modal-area")
    modalArea.innerText = ""
    userDiv = document.createElement("div")
    userDiv.className = "user-info"
    userDiv.innerHTML = `
            <div>
                <span class="initial">${obj.nome[0]}</span>
                <span>${obj.nome}</span>
            </div>
            <span><strong>Número do BI:</strong> ${obj.bi}</span>
            <span><strong>Data de nascimento:</strong> ${obj.data_nascimento.split("-").reverse().join("-")} (${date.getFullYear() - obj.data_nascimento.slice(0, obj.data_nascimento.indexOf("-"))} Anos)</span>
            <span><strong>Classe(s):</strong> ${obj.classes.map(c => c.classe).join("ª, ")}ª</span>
            <span><strong>Curso(s):</strong> ${obj.cursos.map(c => c.curso).join(", ")}</span>
            <span><strong>Turma(s):</strong> ${obj.turmas.map(t => t.turma).join(", ")}</span>
    `
    modalArea.appendChild(userDiv)
}

async function getTeacherInfo(btn) {
    ans = await fetch("/meaculpa/routes/adminRoutes.php?s=teacherInfo", {
        method: "POST",
        body: JSON.stringify({ teacherId: btn.target.value })
    })
    ans = await ans.json()
    console.log(ans)
    writeTeacherInfo(ans)
}

async function registerForm() {
    modalArea = document.querySelector(".modal-area")
    modalArea.innerText = ""
    ans = await fetch("/meaculpa/routes/adminRoutes.php?s=registerOptions")
    ans = await ans.json()

    modalArea.innerHTML = `
        <div class="form">
            <span>Novo Professor</span>
            <form onsubmit='return registerTeacher()'>
                <div class="zone">
                    <label for="nome">Nome</label>
                    <input id="nome" type="text">
                    <label for="bi">BI</label>
                    <input id="bi" type="text">
                    <label for="nascimento">Data de Nascimento</label>
                    <input id="nascimento" type="date" min="${date.getFullYear()-18}-01-01">
                </div>
                <div class="zone">
                    <label for="disciplina">Disciplina</label>
                    <select id="disciplina" multiple></select>
                </div>
                <div class="zone">
                    <label for="classe">Classe</label>
                    <select id="classe" multiple></select>
                </div>
                <div class="zone">
                    <label for="curso">Curso</label>
                    <select id="curso" multiple></select>
                </div>
                <div class="zone">
                    <label for="turma">Turma</label>
                    <select id="turma" multiple></select>
                </div>
                <div class="buttons formButtons">
                    <button onclick=previous() id="prevForm" type="button">Voltar</button>
                    <button type="submit">Salvar</button>
                    <button onclick=next() id="nextForm" type="button">Avançar</button>
                </div>
            </form>
        </div>
    `
    ans.classes.forEach((atr) => {
        classe.innerHTML += `<option value="${atr.id}">${atr.numero}</option>`
    })
    ans.cursos.forEach((atr) => {
        curso.innerHTML += `<option value="${atr.id}">${atr.nome}</option>`
    })
    ans.turmas.forEach((atr) => {
        turma.innerHTML += `<option value="${atr.id}">${atr.nome}</option>`
    })
    ans.disciplinas.forEach((atr) => {
        disciplina.innerHTML += `<option value="${atr.id}">${atr.nome}</option>`
    })
}

function getSelectedValues(arr) {
    arr = [...arr.selectedOptions]
    arr.map((v, i) => {
        arr[i] = arr[i].value
    })
    return arr
}

async function registerTeacher() {
    event.preventDefault()
    const teacher = {
        name: nome.value,
        birthdate: nascimento.value,
        bi: bi.value,
        subjects: getSelectedValues(disciplina),
        courses: getSelectedValues(curso),
        grades: getSelectedValues(classe),
        classes: getSelectedValues(turma)
    }

    for (var atr in teacher) {
        if (teacher[atr] == "" || teacher[atr] == null) {
            showMessage("Preencha todos os campos", "orange","warning")
            return
        }
    }

    ans = await fetch("/meaculpa/routes/adminRoutes.php?s=registerTeacher", {
        method: "POST",
        body: JSON.stringify(teacher)
    })

    ans = await ans.json()
    console.log(ans)
}

function stepRegister(index) {
    formZones = [...document.getElementsByClassName("zone")]
    formZones.forEach((zone) => {
        zone.classList.remove("on")
    })
    formZones[index].classList.add("on")
}

function goBack() {
    if (s > 0)
        s--
    stepRegister(s)
}
function goForward() {
    if (s < 4)
        s++
    stepRegister(s)
}