studentID = null
const date = new Date()

function writeStudents(arr) {
    studentContainer = document.querySelector(".user-container")
    studentContainer.innerText = ""

    for (let x = 0; x < arr.length; x++) {
        if (studentContainer.innerText.includes(arr[x].nome))
            continue
        studentContainer.innerHTML += `
            <div class="user">
            <span>Nome: ${arr[x].nome}</span>
            <span>Classe: ${arr[x].classe}ª</span>
            <span>Curso: ${arr[x].curso}</span>
            <span>Turma: ${arr[x].turma}</span>
            <div class="buttons">
                <button onclick="scoresForm(event);toggleModal()" value=${arr[x].id}>Publicar Nota</button>
                <button onclick="presenceForm(event);toggleModal()" value=${arr[x].id}>Nova presença</button>
            </div>
            </div>
        `
    }
}

async function getStudents() {
    ans = await fetch("/meaculpa/routes/teacherRoutes.php?s=students")
    ans = await ans.json()
    console.log(ans)
    writeStudents(ans)
}
document.addEventListener("DOMContentLoaded", getStudents)

async function scoresForm(btn) {
    studentID = btn.target.value
    modalArea = document.querySelector(".modal-area")
    modalArea.innerText = ""
    ans = await fetch("/meaculpa/routes/teacherRoutes.php?s=marks", {
        method: "POST",
        body: JSON.stringify({ studentId: btn.target.value })
    })
    ans = await ans.json()
    console.log(ans)
    modalArea.innerHTML = `
        <div class="selects">
            <span>Migos</span>
            <form id='scoreForm'>
                <div>

                    <div>
                        <label for="">Disciplina</label>
                        <select id="disciplina"></select>
                    </div>
                    <div>
                        <label for="">Prova</label>
                        <select id="prova"></select>
                    </div>
                    <div>
                        <label for="">Nota</label>
                        <select id="nota"></select>
                    </div>
                </div>
                <div class="buttons selectBtns">
                    <button value="update" type="submit">Atualizar Nota</button>
                    <button value="add" type="submit">Publicar Nota</button>
                </div>
            </form>
        </div>
        `
    ans.disciplinas.forEach((atr) => {
        disciplina.innerHTML += `<option value="${atr.id}">${atr.disciplina}</option>`
    })
    ans.testes.forEach((atr) => {
        prova.innerHTML += `<option value="${atr.id}">${atr.nome}</option>`
    })
    ans.notas.forEach((atr) => {
        nota.innerHTML += `<option value="${atr.id}" style=color:${atr.nota <= 9 ? "red" : "green"}>${atr.nota}</option>`
    })

    const scoreForm = document.getElementById("scoreForm")
    scoreForm.addEventListener("submit", (e) => {
        e.preventDefault()
        const btn = e.submitter
        var action = btn.value

        switch (action) {
            case "update":
                updateStudentMark()
                break
            case "add":
                setStudentMark()
                break
        }
    })
}

async function setStudentMark() {
    event.preventDefault()
    const marks = {
        id: studentID,
        mark: nota.value,
        subject: disciplina.value,
        test: prova.value
    }
    for (var atr in marks) {
        if (marks[atr] == "" || marks[atr] == null) {
            showMessage("Preencha todos os campos", "orange", "warning")
            console.log(marks)
            return
        }
    }
    ans = await fetch("/meaculpa/routes/teacherRoutes.php?s=setMarks", {
        method: "POST",
        body: JSON.stringify(marks)
    })
    ans = await ans.json()
    console.log(ans)
    if (!ans.status) {
        showMessage(ans.msg, "orange", "warning")
        return
    }
    showMessage(ans.msg, "green", "check")
    setTimeout(() => window.location.href = "", waitTime)
}
async function updateStudentMark() {
    event.preventDefault()
    const marks = {
        id: studentID,
        mark: nota.value,
        subject: disciplina.value,
        test: prova.value
    }
    for (var atr in marks) {
        if (marks[atr] == "" || marks[atr] == null) {
            showMessage("Preencha todos os campos", "orange", "warning")
            console.log(marks)
            return
        }
    }
    ans = await fetch("/meaculpa/routes/teacherRoutes.php?s=updateMarks", {
        method: "POST",
        body: JSON.stringify(marks)
    })
    ans = await ans.json()
    console.log(ans)
    if (!ans.status) {
        showMessage(ans.msg, "orange", "warning")
        return
    }
    showMessage(ans.msg, "green", "check")
    setTimeout(() => window.location.href = "", waitTime)
}

async function presenceForm(btn) {
    studentID = btn.target.value
    modalArea = document.querySelector(".modal-area")
    modalArea.innerText = ""
    ans = await fetch("/meaculpa/routes/teacherRoutes.php?s=presences", {
        method: "POST",
        body: JSON.stringify({ studentId: btn.target.value })
    })
    ans = await ans.json()
    modalArea.innerHTML = `
        <div class="selects">
            <span>Migos</span>
            <form onsubmit="return registerPresence()">
                <div>

                    <div>
                        <label for="disciplina">Disciplina</label>
                        <select id="disciplina"></select>
                    </div>
                    <div>
                        <label for="estado">Estado</label>
                        <select id="estado">
                            <option value="0">Ausente</option>
                            <option value="1">Presente</option>
                        </select>
                    </div>
                    <div>
                        <label for="data">Data</label>
                        <input id="data" type='date' 
                        max="${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}" 
                        min="${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()-7).padStart(2,"0")}">
                        </input>
                    </div>
                </div>
                <div class="buttons selectBtns">
                    <button type="submit">Publicar Nota</button>
                </div>
            </form>
        </div>
    `
    ans.disciplinas.forEach((atr) => {
        disciplina.innerHTML += `<option value="${atr.id}">${atr.disciplina}</option>`
    })
}

async function registerPresence() {
    event.preventDefault()
    const presence = {
        id: studentID,
        subject: disciplina.value,
        date: data.value,
        state: estado.value
    }
    ans = await fetch("/meaculpa/routes/teacherRoutes.php?s=setPresence", {
        method: "POST",
        body: JSON.stringify(presence)
    })
    ans = await ans.json()
    console.log(ans)
    if(!ans.status){
        showMessage(ans.msg,"red","warning")
        return
    }
    showMessage(ans.msg,"green","check")
    setTimeout(()=>window.location.href="",waitTime)
}