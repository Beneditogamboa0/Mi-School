const messanger=document.createElement("div")
document.addEventListener("DOMContentLoaded",()=>{
    var username=document.querySelector("span.username")
    username=username.innerText.slice(0,username.innerText.indexOf(" "))
})

function loadUserOptions() {
    userOptions = document.querySelector(".user-options")
    userOptions.classList.toggle("on")
}
userPfp = document.getElementById("user-pfp")
userPfp.addEventListener("click", loadUserOptions)

async function logout() {
    ans = await fetch("../destroy.php", {
        method: "post",
        body: true
    })
    ans = await ans.json()
    window.location.href = ans.redirect
}

logoutBtn = document.querySelector(".user-option-btn")
logoutBtn.addEventListener("click", logout)

function toggleModal() {
    modal = document.querySelector(".modal")
    modal.classList.toggle("on")
}
btnClose=document.querySelector(".close")
btnClose.addEventListener("click",toggleModal)

function showMessage(message,color){
    messanger.classList.add("message-div")
    messanger.classList.add("on")
    messanger.style.backgroundColor=color
    messanger.style.color="white"
    messanger.innerText=message
    document.body.appendChild(messanger)
    setTimeout(()=>messanger.classList.remove("on"),4500)
}

function emptyField(obj){
    for(var atr in obj){
        if(obj[atr]=="" || obj[atr]==null){
            return true
        }
    }
    return false
}