<?php
    session_start();
    if(empty($_SESSION["type"])){
        header("Location: ./login.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../public/styles/global/site.css">
    <link rel="stylesheet" href="../public/fonts/fontawesome/css/all.min.css">
    <link rel="shortcut icon" href="../public/images/favicon.png" type="image/x-icon">
    <title>Mi-School</title>
</head>
<body>
    <?php include_once "../components/modal/modal.php"?>
    <?php include_once "../components/sidebar/sidebar.php"?>
    <?php include_once "../components/main-container/main-container.php"?>
</body>
</html>
<script src="../public/js/dynamicContent.js"></script>
<script src="../public/js/site.js"></script>