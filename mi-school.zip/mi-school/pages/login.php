<?php
    session_start();
    if(isset($_SESSION["type"])){
        header("Location: ./index.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../public/styles/login.css">
    <link rel="shortcut icon" href="../public/images/favicon.png" type="image/x-icon">
    <title>Login</title>
</head>
<body>
    <form onsubmit="return login()">
        <span>Login</span>
        <input id="iemail" type="email" placeholder="Email">
        <input id="ipassword" type="password" placeholder="Senha">
        <button type="submit">Entrar</button>
        <span>Não tem conta ainda? <a href="signup.php">Crie uma conta.</a></span>
    </form>
</body>
</html>
<script src="../public/js/login.js"></script>