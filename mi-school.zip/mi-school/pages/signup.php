<?php
    session_start();
    if(isset($_SESSION["type"])){
        header("Location: ./index.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../public/styles/signup.css">
    <link rel="shortcut icon" href="../public/images/favicon.png" type="image/x-icon">
    <title>Signup</title>
</head>
<body>
    <form onsubmit="return signUp()">
        <span>Criar Conta</span>
        <input id="ifirstName" type="Text" placeholder="Primeiro nome">
        <input id="ilastName" type="Text" placeholder="Último nome">
        <input id="iemail" type="email" placeholder="Email">
        <input id="ipassword" type="password" placeholder="Insira sua senha">
        <input id="ipasswordCheck" type="password" placeholder="Confirme sua senha">
        <label for="iuserType">Escolha o tipo de usuário</label>
        <select id="iuserType">
            <option value="1">Professor</option>
            <option value="2">Aluno</option>
        </select>
        <button type="submit">Criar conta</button>
        <span>Já tem uma conta? <a href="login.php">Faça login</a></span>
    </form>
</body>
</html>
<script src="../public/js/signup.js"></script>