<?php
    include_once __DIR__.("/../controller/user-controller.php");
    login();