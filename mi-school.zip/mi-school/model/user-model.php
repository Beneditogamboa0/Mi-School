<?php
include_once __DIR__ . ("/../config/config.php");
class User
{
    private $name, $email, $password, $userType;
    public function __construct($email, $password, $name = null, $userType = null)
    {
        $this->name = $name;
        $this->email = $email;
        $this->password = $password;
        $this->userType = $userType;
    }
    public function signUp()
    {
        global $con;
        $query = $con->prepare("insert into usuarios (nome,email,senha,id_tipo_usuario) values (?,?,?,?)");
        if (!$query->execute([$this->name, $this->email, $this->password, $this->userType])) {
            return ["status" => false, "msg" => "Ocorreu algum erro durante o registro, tente novamente daqui a algum tempo"];
        }
        return ["status" => true, "msg" => "Seu cadastro foi feito com sucesso"];
    }
    public static function login($email, $password)
    {
        global $con;
        $passCheck = $con->prepare("select senha from usuarios where email=?");
        $passCheck->execute([$email]);
        $passCheck = $passCheck->fetchColumn();

        $emailCheck = $con->prepare("select email from usuarios where email=?");
        $emailCheck->execute([$email]);
        $emailCheck = $emailCheck->fetchColumn();

        if ($email != $emailCheck || $password != $passCheck) {
            return ["status" => false, "msg" => "Verifique as suas credenciais e tente novamente"];
        }

        $query = $con->prepare("select usuarios.id as id, usuarios.nome,tipo_usuario.tipo as tipo_usuario from usuarios join tipo_usuario on id_tipo_usuario=tipo_usuario.id where usuarios.email=?");
        $query->execute([$email]);
        //primeiro pegar a senha e o email, depois comparar com as que foram enviadas e se não coincidirem o status passa para "false"
        return ["status" => true, "msg" => "Usuário encontrado com sucesso","user"=>$query->fetch(PDO::FETCH_ASSOC)];
    }
}