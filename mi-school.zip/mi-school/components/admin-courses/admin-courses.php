<link rel="stylesheet" href="../components/admin-courses/admin-courses.css">
<div class="admin-courses">
    <div class="courses-list">
        <div class="course"></div>
        <div class="course"></div>
        <div class="course"></div>
        <div class="course"></div>
    </div>
</div>