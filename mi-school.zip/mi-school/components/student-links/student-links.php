<li onclick="loadContent('../components/student-main/student-main.php')"><span>Principal</span></li>
<li onclick="loadContent('../components/student-informations/student-informations.php/')"><span>Informações pessoais</span></li>
<li onclick="loadContent('../components/student-marks/student-marks.php')"><span>Notas</span></li>
<li onclick="loadContent('../components/student-presence/student-presence.php')"><span>Presenças</span></li>
<li onclick="loadContent('../components/student-subjects/student-subjects.php')"><span>Disciplinas</span></li>