<link rel="stylesheet" href="../components/admin-main/admin-main.css">
<div class="admin-main">
    <div class="info">
        <div style="grid-area: a1;">
            <span>Total de Alunos</span>
            200
        </div>
        <div style="grid-area: a2;">
            <span>Total de Professores</span>
            15
        </div>
        <div style="grid-area: a3;">
            <span>Total de Cursos</span>
            7
        </div>
        <div style="grid-area: a4;">
            <span>Curso com melhor aproveitamento</span>
            Informática: 70%
        </div>
        <div style="grid-area: a5;">
            <span>Classe com melhor aproveitamento</span>
            13ª classe: 92%
        </div>
    </div>
</div>