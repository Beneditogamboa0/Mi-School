<link rel="stylesheet" href="../components/sidebar/sidebar.css">
<nav>
    <span class="logo">Mi-School <i class="fa fa-pencil"></i></span>
    <ul>
        <?php
        $userType=$_SESSION["type"];
        switch($userType){
            case "Aluno":
                include_once __DIR__."/../student-links/student-links.php";
                break;
            case "Professor":
                include_once __DIR__."/../teacher-links/teacher-links.php";
                break;
            case "Admin":
                include_once __DIR__."/../admin-links/admin-links.php";
                break;
        }
        ?>
    </ul>
    <footer>
        <div class="user-options">
            <button class="user-option-btn">Fazer Logout</button>
            <button class="user-option-btn">Alterar senha</button>
        </div>
        <img src="../public/images/default-pfp.jpg" alt="pfp" id="user-pfp"><span id="username"><?=$_SESSION["name"]?></span>
    </footer>
</nav>