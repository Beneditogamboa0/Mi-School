<link rel="stylesheet" href="../components/student-subjects/student-subjects.css">
<div class="student-subjects">
    <span>Minhas Disciplinas</span>
    <div class="subjects">
        <div>
            <span>Disciplina</span>
            <span>h1,h2,h3</span>
        </div>
        <div>
            <span>Disciplina</span>
            <span>h1,h2,h3</span>
        </div>
        <div>
            <span>Disciplina</span>
            <span>h1,h2,h3</span>
        </div>
    </div>
</div>