<link rel="stylesheet" href="../components/student-presence/student-presence.css">
<div class="student-presence">
    <div class="presence">
        <span>Disciplina</span>
        <div class="presence-info">
            <div>
                <span>Total de faltas</span>
                txt
            </div>
            <div>
                <span>Total de presenças</span>
                txt
            </div>
            <div>
                <span>Total geral</span>
                txt
            </div>
        </div>
    </div>
    <div class="presence">
        <span>Disciplina</span>
        <div class="presence-info">
            <div>
                <span>Total de faltas</span>
                txt
            </div>
            <div>
                <span>Total de presenças</span>
                txt
            </div>
            <div>
                <span>Total geral</span>
                txt
            </div>
        </div>
    </div>
</div>