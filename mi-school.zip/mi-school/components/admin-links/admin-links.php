<li onclick="loadContent('../components/admin-main/admin-main.php')"><span>Principal</span></li>
<li onclick="loadContent('../components/admin-student/admin-student.php')"><span>Alunos</span></li>
<li onclick="loadContent('../components/admin-teacher/admin-teacher.php')"><span>Professores</span></li>
<li onclick="loadContent('../components/admin-courses/admin-courses.php')"><span>Cursos</span></li>
<li onclick="loadContent('../components/admin-grades/admin-grades.php')"><span>Classes</span></li>