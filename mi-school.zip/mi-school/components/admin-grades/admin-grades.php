<link rel="stylesheet" href="../components/admin-grades/admin-grades.css">
<div class="admin-grades">
    <div class="grades-list">
        <div class="grade"></div>
        <div class="grade"></div>
        <div class="grade"></div>
        <div class="grade"></div>
    </div>
</div>