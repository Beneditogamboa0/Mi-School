async function signUp() {
    event.preventDefault()
    const user = {
        name: ifirstName.value + " " + ilastName.value,
        email: iemail.value,
        password: ipassword.value,
        userType: iuserType.value
    }
    ans = await fetch("./../routes/userSignUp.php", {
        method: "post",
        body: JSON.stringify(user),
        header: { "content-type": "application/json" }
    })
    ans = await ans.json()
    if(ans.status)
        window.location.href="./login.php"
}