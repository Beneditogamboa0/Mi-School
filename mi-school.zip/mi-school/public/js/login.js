async function login(){
        event.preventDefault()
        const user={
            email:iemail.value,
            password:ipassword.value
        }
        ans=await fetch("./../routes/userLogin.php",{
            method:"post",
            body:JSON.stringify(user),
            header:{"content-type":"application/json"}
        })
        ans=await ans.json()
        if(ans.status)
            window.location.href="./index.php"
    }