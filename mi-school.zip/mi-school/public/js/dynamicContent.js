async function loadContent(page){
    main=document.getElementById("main-container")
    ans=await fetch(page)
    ans=await ans.text()
    main.innerHTML=`${ans}`
}